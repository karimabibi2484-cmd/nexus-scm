export const navGroups = [
  { label: 'OPERATIONS', items: [
    ['Overview', 'LayoutDashboard'], ['Live Control Tower', 'Radar'], ['Disruption Intelligence', 'Siren'],
    ['Dependency Network', 'Network'], ['Scenario Planning', 'GitCompare'], ['Recovery Optimization', 'Target']
  ]},
  { label: 'EXECUTION', items: [
    ['Logistics & Rerouting', 'Truck'], ['Cold-Chain Monitoring', 'Thermometer'], ['Inventory & Medicines', 'Package'],
    ['AI Agent Center', 'Bot']
  ]},
  { label: 'GOVERNANCE', items: [
    ['Compliance & Audit', 'ShieldCheck'], ['Reports & Analytics', 'ChartNoAxesCombined'], ['Settings', 'Settings']
  ]}
];

export const initialDisruptions = [
  { id: 'DSP-2408', event: 'Flood risk / road closure', location: 'Kampala–Jinja corridor, Uganda', severity: 'Critical', shipments: 3, delay: '4–6 hrs', status: 'Recovery planning', action: 'Compare alternate routes', confidence: 94 },
  { id: 'DSP-2407', event: 'Cold-room power instability', location: 'Kisumu Distribution Hub, Kenya', severity: 'High', shipments: 5, delay: '1–2 hrs', status: 'Monitoring', action: 'Verify backup generator', confidence: 88 },
  { id: 'DSP-2406', event: 'Border processing delay', location: 'Malaba border, Kenya–Uganda', severity: 'Medium', shipments: 2, delay: '2 hrs', status: 'Mitigation active', action: 'Re-sequence deliveries', confidence: 81 },
  { id: 'DSP-2405', event: 'Refrigerated vehicle maintenance', location: 'Arusha region, Tanzania', severity: 'Low', shipments: 1, delay: '45 mins', status: 'Assigned', action: 'Assign backup vehicle', confidence: 76 }
];

export const inventory = [
  { id: 'MED-001', name: 'Routine vaccine — demo product', batch: 'VX-24-118', hub: 'Nairobi Central', qty: 12400, expiry: '2027-04-18', temp: 'In range', criticality: 'Critical', reorder: 'Healthy' },
  { id: 'MED-002', name: 'Insulin — demo product', batch: 'IN-24-042', hub: 'Kampala Regional', qty: 2180, expiry: '2027-02-09', temp: 'In range', criticality: 'High', reorder: 'Watch' },
  { id: 'MED-003', name: 'Temperature-sensitive injection', batch: 'TS-24-076', hub: 'Kisumu Distribution', qty: 860, expiry: '2026-12-21', temp: 'Review required', criticality: 'High', reorder: 'Reorder soon' },
  { id: 'MED-004', name: 'Vaccine carrier stock — demo', batch: 'VC-24-009', hub: 'Kigali Medical Hub', qty: 5300, expiry: '2027-08-30', temp: 'In range', criticality: 'Medium', reorder: 'Healthy' },
  { id: 'MED-005', name: 'Biologic medicine — demo product', batch: 'BM-24-031', hub: 'Dar es Salaam Hub', qty: 420, expiry: '2026-11-29', temp: 'In range', criticality: 'Critical', reorder: 'Reorder soon' }
];

export const agents = [
  { id: 1, name: 'Disruption Sensing Agent', task: 'Monitoring weather, transport and facility signals', status: 'Monitoring', output: 'Flood-risk signal detected on Kampala–Jinja corridor.' },
  { id: 2, name: 'Dependency Intelligence Agent', task: 'Tracing downstream medicine and facility dependencies', status: 'Analyzing', output: '3 shipments and 2 healthcare facilities potentially affected.' },
  { id: 3, name: 'Scenario Planning Agent', task: 'Generating alternative recovery scenarios', status: 'Recommendation Ready', output: '3 recovery options generated for comparison.' },
  { id: 4, name: 'Coordinated Optimization Engine', task: 'Balancing delivery, cold-chain risk and cost', status: 'Analyzing', output: 'Ranking feasible plans using demo constraints.' },
  { id: 5, name: 'Risk Firewall + Human Approval', task: 'Checking safety rules and approval thresholds', status: 'Awaiting Approval', output: 'Human approval required before route change.' },
  { id: 6, name: 'Rerouting Agent', task: 'Preparing alternate carrier and route assignment', status: 'Idle', output: 'No operational route changes executed in demo.' },
  { id: 7, name: 'Inventory Agent', task: 'Checking buffer stock and transfer options', status: 'Monitoring', output: 'Nairobi Central has potential buffer stock.' },
  { id: 8, name: 'Recovery Verification Agent', task: 'Verifying shipment status and temperature evidence', status: 'Idle', output: 'Awaiting recovery action and shipment evidence.' },
  { id: 9, name: 'Compliance, Audit & Learning Agents', task: 'Recording decisions and outcome feedback', status: 'Monitoring', output: 'Demo event log is ready to capture actions.' }
];

export const scenarios = [
  { id: 'A', name: 'Continue existing route', eta: '6.0 hrs', cost: '$420', recovered: 1, risk: 'High', score: 48, description: 'Lowest immediate change, but remains exposed to the reported road disruption.' },
  { id: 'B', name: 'Reroute via alternate corridor', eta: '3.5 hrs', cost: '$610', recovered: 3, risk: 'Low', score: 91, description: 'Uses a simulated alternate corridor and an available refrigerated vehicle.' },
  { id: 'C', name: 'Transfer stock from nearby hub', eta: '2.8 hrs', cost: '$760', recovered: 3, risk: 'Medium', score: 84, description: 'Uses available buffer stock; requires inventory and cold-storage validation.' },
  { id: 'D', name: 'Alternate qualified supplier', eta: '18 hrs', cost: '$1,180', recovered: 3, risk: 'Medium', score: 65, description: 'Useful for longer disruptions but unlikely to resolve the immediate delivery window.' }
];

export const auditRows = [
  { time: '09:42:16', event: 'DSP-2408', action: 'Alternate route proposed', actor: 'Optimization Engine', result: 'Awaiting approval' },
  { time: '09:38:04', event: 'DSP-2407', action: 'Generator verification requested', actor: 'Risk Firewall', result: 'Assigned' },
  { time: '09:22:51', event: 'DSP-2406', action: 'Delivery sequence adjusted', actor: 'Operations planner', result: 'Mitigation active' },
  { time: '08:57:30', event: 'DSP-2405', action: 'Backup vehicle option identified', actor: 'Rerouting Agent', result: 'Recommendation ready' }
];